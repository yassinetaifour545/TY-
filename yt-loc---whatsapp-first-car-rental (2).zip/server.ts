import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { FLEET_CARS } from './src/data/fleet.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// High-reasoning Moroccan road trip and fleet recommendation engine
function generateCarRecommendation(query: string, passengers: number = 2, luggage: number = 2) {
  const q = query.toLowerCase();

  // High Atlas mountain passes & Sahara desert routes or demanding terrain
  if (
    q.includes('desert') ||
    q.includes('merzouga') ||
    q.includes('atlas') ||
    q.includes('mountain') ||
    q.includes('dunes') ||
    q.includes('gorge') ||
    passengers >= 4 ||
    luggage >= 3
  ) {
    if (q.includes('luxury') || q.includes('executive') || q.includes('flagship') || q.includes('power')) {
      return {
        recommendedCarId: 'vw-t-roc',
        carName: 'Volkswagen T-Roc (600 DH/day)',
        rationale:
          'For demanding terrain across the High Atlas passes (Tizi n\'Tichka) and long-distance desert routes, the Volkswagen T-Roc delivers turbocharged torque, German high-speed stability, and commanding ride height.',
        itineraryTips: [
          'Take the scenic N9 route through Tizi n\'Tichka pass during daylight hours for spectacular mountain views.',
          'Stock up on bottled water and download offline maps before heading south towards Ouarzazate and Zagora.',
          'Toll plazas accept cash in Moroccan Dirhams (MAD); keep 50 and 100 DH bills handy.',
        ],
      };
    }
    return {
      recommendedCarId: 'hyundai-tucson',
      carName: 'Hyundai Tucson (450 DH/day)',
      rationale:
        'With an expansive 598L trunk and commanding ground clearance, the Hyundai Tucson effortlessly swallows 4 passenger bags while providing smooth automatic cruising across Moroccan valleys and coastal highways.',
      itineraryTips: [
        'Great ground clearance makes the Tucson ideal for gravel approaches to desert kasbahs and Palmeraies.',
        'High air conditioning performance ensures passenger comfort during warmer midday desert drives.',
        'Speed radars are strictly enforced on the Marrakech-Agadir and Marrakech-Casablanca A3 autoroutes.',
      ],
    };
  }

  // Automatic transmission preference
  if (q.includes('auto') || q.includes('automatic')) {
    return {
      recommendedCarId: 'mg-3',
      carName: 'MG 3 Automatic (350 DH/day)',
      rationale:
        'The MG 3 offers effortless automatic transmission, compact dimensions for maneuvering crowded city center parking, and sharp responsive handling at an accessible 350 DH/day.',
      itineraryTips: [
        'Ideal for stress-free navigating inside Gueliz (Marrakech) and Maarif (Casablanca).',
        'Automatic transmission removes stop-and-go fatigue during rush hours.',
      ],
    };
  }

  // Budget, couple, coastal or economical touring
  if (
    q.includes('budget') ||
    q.includes('cheap') ||
    q.includes('econom') ||
    q.includes('value') ||
    q.includes('couple') ||
    q.includes('surf') ||
    (passengers <= 2 && luggage <= 2)
  ) {
    return {
      recommendedCarId: 'dacia-sandero',
      carName: 'Dacia Sandero Stepway (270 DH/day)',
      rationale:
        'At only 270 DH/day with exceptional 4.8L/100km diesel efficiency, the Dacia Sandero Stepway gives you elevated crossover ground clearance, Apple CarPlay, and the best price-to-comfort ratio in Morocco.',
      itineraryTips: [
        'Outstanding fuel economy lets you tour Morocco from Tangier to Essaouira with minimal fuel stops.',
        'Compact footprint makes parking near medina gates (e.g. Bab Doukkala in Marrakech) simple.',
      ],
    };
  }

  // Large family or heavy luggage
  if (q.includes('family') || q.includes('luggage') || q.includes('bags') || luggage >= 3) {
    return {
      recommendedCarId: 'dacia-logan',
      carName: 'Dacia Logan (280 DH/day)',
      rationale:
        'The Dacia Logan boasts a monumental 528L trunk at just 280 DH/day, easily holding multiple large suitcases while delivering legendary Moroccan durability.',
      itineraryTips: [
        'Unmatched trunk space for souvenirs and oversized baggage.',
        'Very economical diesel engine with widespread serviceability everywhere in Morocco.',
      ],
    };
  }

  // Default refined urban touring
  return {
    recommendedCarId: 'clio-5',
    carName: 'Renault Clio 5 (300 DH/day)',
    rationale:
      'The Renault Clio 5 is Morocco\'s favorite premium compact: modern digital instrumentation, refined suspension, and sleek aesthetics suited for both city dinner dates and coastal highway cruising.',
    itineraryTips: [
      'Pure Vision LED headlights provide exceptional visibility on evening intercity drives.',
      'Refined aerodynamics reduce wind noise on the Casablanca-Marrakech-Agadir highway.',
    ],
  };
}

// POST /api/recommend-car
app.post('/api/recommend-car', (req, res) => {
  const { query, passengers = 2, luggage = 2 } = req.body;

  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Query is required' });
  }

  const recommendation = generateCarRecommendation(query, passengers, luggage);
  return res.json({
    ...recommendation,
    source: 'concierge-expert-engine',
  });
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`YT-LOC server running on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
