export interface Car {
  id: string;
  name: string; // Creative lifestyle title e.g. "The City Cruiser"
  model: string; // Exact car model name e.g. "Dacia Sandero"
  tagline: string;
  dailyRate: number; // in DH
  category: 'Compact & City' | 'SUV & Crossover' | 'Premium & SUV';
  image: string;
  description: string;
  specs: {
    seats: number;
    transmission: 'Manual' | 'Automatic' | 'DSG Auto';
    fuel: 'Diesel' | 'Essence / Gasoline' | 'Hybrid';
    doors: number;
    luggage: string;
    consumption: string;
    airConditioning: boolean;
  };
  features: string[];
  recommendedFor: string;
  badge?: string;
}

export const FLEET_CARS: Car[] = [
  {
    id: 'dacia-sandero',
    name: 'The City Cruiser',
    model: 'Dacia Sandero Stepway',
    tagline: 'Agile, elevated and economical for lively Moroccan medinas and coastal escapes.',
    dailyRate: 270,
    category: 'Compact & City',
    image: '/assets/aistudio/Gemini_Generated_Image_i7nzpoi7nzpoi7nz_ab9e4283.jpg',
    description: 'Elevated ground clearance and modern crossover proportions. Perfectly sized for tight historical streets while offering plush suspension over country roads.',
    specs: {
      seats: 5,
      transmission: 'Manual',
      fuel: 'Diesel',
      doors: 5,
      luggage: '328 Liters (2 Medium Bags)',
      consumption: '4.8L / 100km',
      airConditioning: true,
    },
    features: ['Apple CarPlay & Android Auto', 'Hill Start Assist', 'Roof Rails', 'Rear Parking Sensors', 'Eco-Drive Mode'],
    recommendedFor: 'Couples, solo adventurers, budget-conscious road trippers.',
    badge: 'Best Value',
  },
  {
    id: 'dacia-logan',
    name: 'The Practical Voyager',
    model: 'Dacia Logan',
    tagline: 'Proven endurance with huge luggage space for long family road journeys.',
    dailyRate: 280,
    category: 'Compact & City',
    image: '/assets/aistudio/Gemini_Generated_Image_4drfxj4drfxj4drf_023ad67b.jpg',
    description: 'Morocco’s most trusted highway companion. Built with an enormous 528-liter boot that easily accommodates golf clubs, family luggage, and shopping from the souks.',
    specs: {
      seats: 5,
      transmission: 'Manual',
      fuel: 'Diesel',
      doors: 4,
      luggage: '528 Liters (3-4 Large Suitcases)',
      consumption: '4.5L / 100km',
      airConditioning: true,
    },
    features: ['Extra Large Trunk', 'Cruise Control', 'Speed Limiter', 'Bluetooth Hands-free', 'Robust Suspension'],
    recommendedFor: 'Families, business travelers with luggage, long highway treks.',
  },
  {
    id: 'clio-5',
    name: 'The Refined Urbanite',
    model: 'Renault Clio 5',
    tagline: 'Sculpted European flair, premium cabin finish, and dynamic road poise.',
    dailyRate: 300,
    category: 'Compact & City',
    image: '/assets/aistudio/Gemini_Generated_Image_qo6bjgqo6bjgqo6b_f65bdf03.jpg',
    description: 'Sophisticated aesthetics meets agile handling. Equipped with a digital smart cockpit, ergonomic seats, and ultra-smooth highway cruising capabilities.',
    specs: {
      seats: 5,
      transmission: 'Manual',
      fuel: 'Diesel',
      doors: 5,
      luggage: '391 Liters (2 Large + 1 Small)',
      consumption: '4.2L / 100km',
      airConditioning: true,
    },
    features: ['Full LED Pure Vision Headlights', 'Digital Cockpit Display', 'Touchscreen Infotainment', 'Lane Keeping Assist', 'Keyless Entry'],
    recommendedFor: 'Design lovers, executive city hops, romantic weekend getaways.',
    badge: 'Popular',
  },
  {
    id: 'peugeot-208',
    name: 'The Modern Icon',
    model: 'Peugeot 208',
    tagline: 'Feline design signature, futuristic 3D i-Cockpit, and whisper-quiet drive.',
    dailyRate: 320,
    category: 'Compact & City',
    image: '/assets/aistudio/Gemini_Generated_Image_q0f75q0f75q0f75q_fe3136ae.jpg',
    description: 'A striking head-turner with Peugeot’s claw-effect LED lights, compact sports steering wheel, and outstanding acoustic insulation.',
    specs: {
      seats: 5,
      transmission: 'Manual',
      fuel: 'Diesel',
      doors: 5,
      luggage: '311 Liters (2 Standard Bags)',
      consumption: '4.0L / 100km',
      airConditioning: true,
    },
    features: ['3D Holographic Instrument Cluster', 'Compact Leather Sport Wheel', 'Speed Sign Recognition', 'Automatic Emergency Braking', 'High-Gloss Accents'],
    recommendedFor: 'Style-conscious drivers, premium compact touring.',
  },
  {
    id: 'mg-3',
    name: 'The Dynamic Sport',
    model: 'MG 3',
    tagline: 'Punchy British spirit, automatic transmission, and fun-loving agility.',
    dailyRate: 350,
    category: 'Compact & City',
    image: '/assets/aistudio/Gemini_Generated_Image_q19p7eq19p7eq19p_0a84e6b5.jpg',
    description: 'Effortless automatic driving with eye-catching personality. Perfect for stress-free commuting in Marrakech or Casablanca traffic.',
    specs: {
      seats: 5,
      transmission: 'Automatic',
      fuel: 'Essence / Gasoline',
      doors: 5,
      luggage: '293 Liters (2 Bags)',
      consumption: '5.6L / 100km',
      airConditioning: true,
    },
    features: ['Smooth Automatic Gearbox', '8-inch HD Touchscreen', 'Rear Parking Camera', 'DAB Digital Audio', 'Tyre Pressure Monitoring'],
    recommendedFor: 'Automatic gearbox preference, hassle-free city driving.',
    badge: 'Automatic',
  },
  {
    id: 'changan-cs35',
    name: 'The High-Tech Explorer',
    model: 'Changan CS35',
    tagline: 'Elevated command view, intelligent driver assist, and airy cabin comfort.',
    dailyRate: 450,
    category: 'SUV & Crossover',
    image: '/assets/aistudio/Gemini_Generated_Image_qz5ey6qz5ey6qz5e_fe2f9b58.jpg', // SUV reference fallback
    description: 'A feature-packed compact SUV boasting dual panoramic digital displays, plush synthetic leather seats, and impressive high-chassis stability for exploring Morocco’s valleys.',
    specs: {
      seats: 5,
      transmission: 'Automatic',
      fuel: 'Essence / Gasoline',
      doors: 5,
      luggage: '403 Liters (3 Large Suitcases)',
      consumption: '6.4L / 100km',
      airConditioning: true,
    },
    features: ['360-Degree Panoramic Camera', 'Dual 10.25-inch Screens', 'Panoramic Sunroof', 'Smart Keyless Access', 'Leatherette Comfort Seats'],
    recommendedFor: 'Small families, groups wanting elevated road perspective & automatic ease.',
    badge: 'Feature Rich',
  },
  {
    id: 'hyundai-tucson',
    name: 'The Premium Adventurer',
    model: 'Hyundai Tucson',
    tagline: 'Geometric luxury styling, cavernous cabin, and supreme highway refinement.',
    dailyRate: 450,
    category: 'SUV & Crossover',
    image: '/assets/aistudio/Gemini_Generated_Image_qz5ey6qz5ey6qz5e_fe2f9b58.jpg',
    description: 'The benchmark modern SUV. Striking parametric grille with hidden jewel headlights, whisper-silent high-speed cruising, and generous boot space for Atlas Mountain or coastal expeditions.',
    specs: {
      seats: 5,
      transmission: 'Automatic',
      fuel: 'Diesel',
      doors: 5,
      luggage: '598 Liters (4 Large Suitcases)',
      consumption: '5.2L / 100km',
      airConditioning: true,
    },
    features: ['Parametric Hidden Lights', 'SmartSense Safety Suite', 'Dual-Zone Climate Control', 'Wireless Smartphone Charging', 'Drive Mode Selector'],
    recommendedFor: 'Road trips, Atlas Mountain journeys, families needing generous space.',
    badge: 'Top Pick',
  },
  {
    id: 'vw-t-roc',
    name: 'The Executive Performer',
    model: 'VW T-Roc',
    tagline: 'Uncompromising German precision, turbocharged punch, and commanding poise.',
    dailyRate: 600,
    category: 'Premium & SUV',
    image: '/assets/aistudio/Gemini_Generated_Image_wa4n4gwa4n4gwa4n_687e4be0.jpg',
    description: 'Flagship prestige in a dynamic SUV silhouette. Lightning-fast DSG transmission, firm Germanic chassis tuning, and high-end materials designed for discerning executives and travelers.',
    specs: {
      seats: 5,
      transmission: 'DSG Auto',
      fuel: 'Diesel',
      doors: 5,
      luggage: '445 Liters (3-4 Suitcases)',
      consumption: '5.1L / 100km',
      airConditioning: true,
    },
    features: ['7-Speed DSG Automatic', 'Digital Cockpit Pro', 'IQ.Drive Adaptive Cruise', 'Ambient Interior Illumination', 'Sport Comfort Seats'],
    recommendedFor: 'Luxury seekers, executive business travel, premium coastal drives.',
    badge: 'Premium Flagship',
  },
];

export const MOROCCAN_LOCATIONS = [
  { id: 'rak-airport', name: 'Marrakech Menara Airport (RAK)', icon: 'plane' },
  { id: 'rak-city', name: 'Marrakech Downtown & Medina Hotels', icon: 'building' },
  { id: 'cmn-airport', name: 'Casablanca Mohammed V Airport (CMN)', icon: 'plane' },
  { id: 'cmn-city', name: 'Casablanca Downtown / Maarif / Corniche', icon: 'building' },
  { id: 'aga-airport', name: 'Agadir Al Massira Airport (AGA)', icon: 'plane' },
  { id: 'aga-city', name: 'Agadir Marina & Beach Hotels', icon: 'building' },
  { id: 'tng-airport', name: 'Tangier Ibn Battouta Airport (TNG)', icon: 'plane' },
  { id: 'rba-airport', name: 'Rabat-Salé Airport (RBA)', icon: 'plane' },
  { id: 'fez-airport', name: 'Fez-Saïss Airport (FEZ)', icon: 'plane' },
];

export const CONTACT_INFO = {
  brandName: 'YT-LOC',
  companyName: 'YT-LOC Car Rental & Mobility Morocco',
  whatsappRaw: '0653134372',
  whatsappDisplay: '+212 653-134372',
  whatsappInternational: '212653134372',
  email: 'contact.yass@gmail.com',
  address: 'Avenue Mohammed VI, Hivernage, Marrakech / CMN Hub, Morocco',
  operatingHours: '24/7 VIP Concierge & Airport Handover',
};
