import React from 'react';
import { MessageCircle, ShieldCheck, Tag, Plane, Sparkles } from 'lucide-react';
import { CONTACT_INFO } from '../data/fleet';

export const WhyChooseUs: React.FC = () => {
  const benefits = [
    {
      icon: MessageCircle,
      title: 'Instant WhatsApp Support',
      description:
        'No hold music, no email delays. Chat directly with a real concierge in English, French, or Arabic to confirm bookings and coordinate logistics in minutes.',
      tag: 'Direct 0653134372',
    },
    {
      icon: ShieldCheck,
      title: 'Modern, Meticulous Fleet',
      description:
        'Our cars are new, thoroughly cleaned before every rental, mechanically inspected, and backed by 24/7 roadside assistance across all Morocco.',
      tag: 'Inspected & Certified',
    },
    {
      icon: Tag,
      title: '100% Transparent Pricing',
      description:
        'The price you see in Moroccan Dirhams is the exact price you pay. No airport surcharge surprises, no mandatory hidden insurances, no credit card shocks.',
      tag: 'Zero Hidden Fees',
    },
    {
      icon: Plane,
      title: 'Seamless Airport Delivery',
      description:
        'We meet you right outside terminal arrivals at Marrakech Menara (RAK), Casablanca (CMN), or Agadir with your keys ready so your journey begins instantly.',
      tag: 'Terminal Meet & Greet',
    },
  ];

  return (
    <section id="why-choose-us" className="py-20 lg:py-28 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Visual Side (Left in split layout) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="relative rounded-3xl bg-slate-900 text-white p-8 overflow-hidden shadow-xl">
              {/* Background ambient lighting */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/20 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 space-y-6">
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>The YT-LOC Difference</span>
                </div>

                <h3 className="text-3xl font-extrabold tracking-tight font-['Outfit'] leading-snug">
                  Built for travelers who value freedom over paperwork.
                </h3>

                <p className="text-slate-300 text-sm leading-relaxed">
                  Traditional car rental companies make you wait in line, upsell you at the counter, and hide fees. We flipped the model: transparent pricing on the web, warm personal concierge on WhatsApp.
                </p>

                {/* Car Showcase preview */}
                <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Direct Airport Delivery</span>
                    <span className="text-emerald-400 font-semibold">Included Free</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Payment on Delivery</span>
                    <span className="text-white font-semibold">Cash or Card Accepted</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Concierge Response Time</span>
                    <span className="text-emerald-400 font-semibold font-mono">&lt; 5 minutes</span>
                  </div>
                </div>

                <div className="pt-2">
                  <a
                    href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I want to ask a question before booking.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 w-full py-3 px-5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm rounded-xl transition-colors shadow-sm"
                  >
                    <MessageCircle className="w-4 h-4 fill-white text-white" />
                    <span>Chat with Concierge Now</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Benefits List (Right in split layout) */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
                <span>Why Travelers Choose Us</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span>Trust & Transparency</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-['Outfit']">
                A better way to rent in Morocco.
              </h2>
              <p className="text-slate-600 text-base leading-relaxed">
                Whether you're landing in Marrakech for a desert expedition or visiting Casablanca for business, we ensure your vehicle is prepped, spotlessly clean, and waiting for you.
              </p>
            </div>

            <div className="space-y-6">
              {benefits.map((b) => {
                const Icon = b.icon;
                return (
                  <div
                    key={b.title}
                    className="flex items-start gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-200/70 hover:bg-slate-50/80 transition-colors"
                  >
                    <div className="w-11 h-11 rounded-xl bg-white border border-slate-200 text-emerald-700 flex items-center justify-center shrink-0 shadow-xs">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-slate-950 font-['Outfit']">
                          {b.title}
                        </h4>
                        <span className="text-[11px] font-semibold text-emerald-700">
                          · {b.tag}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {b.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
