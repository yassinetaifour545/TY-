import React from 'react';
import { Car, CalendarCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface HowItWorksProps {
  onExploreFleet: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onExploreFleet }) => {
  const steps = [
    {
      number: '01',
      title: 'Choose Your Car',
      description:
        'Browse our curated collection of 8 modern vehicles. From economical city cruisers at 270 DH to executive turbo SUVs, inspect real specs and upfront daily rates.',
      icon: Car,
    },
    {
      number: '02',
      title: 'Tell Us Your Plans',
      description:
        'Select your dates, pick-up airport or city terminal, and any optional extras like a child seat or full protection. Our system calculates the exact price in DH.',
      icon: CalendarCheck,
    },
    {
      number: '03',
      title: 'Confirm on WhatsApp',
      description:
        'One click opens WhatsApp with your pre-filled reservation. A real YT-LOC concierge immediately checks availability, locks your car, and sends terminal handover details.',
      icon: CheckCircle2,
    },
  ];

  return (
    <section id="how-it-works" className="py-20 lg:py-28 bg-slate-50/70 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
            <span>Seamless 3-Step Process</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>Zero Bureaucracy</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-['Outfit']">
            How WhatsApp-First Rental Works
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            We replaced old rental counters, long email queues, and confusing paperwork with a digital showroom and a direct WhatsApp concierge.
          </p>
        </div>

        {/* 3 Step Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={step.number}
                className="relative bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-black text-slate-300 font-mono">
                      {step.number}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-950 font-['Outfit'] mb-3">
                    {step.title}
                  </h3>

                  <p className="text-sm text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center gap-2 text-xs font-semibold text-emerald-700">
                  <span>Fast & Direct</span>
                  <span aria-hidden="true">·</span>
                  <span>Instant Handover</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-14 text-center">
          <button
            type="button"
            onClick={onExploreFleet}
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-slate-950 rounded-xl hover:bg-slate-800 transition-colors shadow-sm cursor-pointer"
          >
            <span>Ready to pick a car? Explore the fleet</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
