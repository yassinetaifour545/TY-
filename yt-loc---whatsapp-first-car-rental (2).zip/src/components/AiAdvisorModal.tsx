import React, { useState } from 'react';
import { X, Sparkles, Send, ArrowRight, Lightbulb, Compass, Loader2 } from 'lucide-react';
import { Car, FLEET_CARS } from '../data/fleet';

interface AiAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCar: (car: Car) => void;
}

export const AiAdvisorModal: React.FC<AiAdvisorModalProps> = ({
  isOpen,
  onClose,
  onSelectCar,
}) => {
  const [query, setQuery] = useState('');
  const [passengers, setPassengers] = useState(2);
  const [luggage, setLuggage] = useState(2);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    recommendedCarId: string;
    carName: string;
    rationale: string;
    itineraryTips: string[];
    source?: string;
  } | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    'Marrakech to Merzouga Sahara Desert (4 adults, mountain passes & sand tracks)',
    'Economical couple roadtrip: Marrakech, Essaouira & Taghazout surf coast',
    'Casablanca business meetings & airport hops (need smooth automatic)',
    'High Atlas mountain villages with large family luggage',
  ];

  const handleRecommend = async (customQuery?: string) => {
    const textToSubmit = customQuery || query;
    if (!textToSubmit.trim()) return;

    setLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/recommend-car', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSubmit,
          passengers,
          luggage,
        }),
      });

      if (!res.ok) throw new Error('API route not available');
      const data = await res.json();
      setResult(data);
    } catch {
      // Robust client-side Moroccan travel recommendation engine
      const q = textToSubmit.toLowerCase();
      let match = FLEET_CARS.find((c) => c.id === 'hyundai-tucson')!;
      let rationale = 'With an expansive 598L trunk and commanding ground clearance, the Hyundai Tucson effortlessly handles luggage while providing smooth automatic cruising across Moroccan valleys and highways.';
      let tips = [
        'Take the scenic N9 route through Tizi n\'Tichka pass in daylight hours for breathtaking views.',
        'Always keep small cash (50 & 100 DH bills) ready for highway toll plazas.',
      ];

      if (q.includes('luxury') || q.includes('executive') || q.includes('best') || q.includes('power')) {
        match = FLEET_CARS.find((c) => c.id === 'vw-t-roc') || match;
        rationale = 'For demanding terrain across High Atlas passes and long-distance desert routes, the Volkswagen T-Roc delivers turbocharged torque, German high-speed stability, and commanding ride height.';
        tips = [
          'DSG automatic transmission makes steep mountain switchbacks completely effortless.',
          'Speed radars are strictly enforced on the Marrakech-Agadir and Marrakech-Casablanca A3 autoroutes.',
        ];
      } else if (q.includes('auto') || q.includes('automatic')) {
        match = FLEET_CARS.find((c) => c.id === 'mg-3') || match;
        rationale = 'The MG 3 offers effortless automatic transmission, compact dimensions for maneuvering crowded city center parking, and sharp responsive handling at an accessible 350 DH/day.';
        tips = [
          'Ideal for stress-free navigating inside Gueliz (Marrakech) and Maarif (Casablanca).',
          'Automatic transmission removes stop-and-go fatigue during rush hours.',
        ];
      } else if (q.includes('budget') || q.includes('cheap') || q.includes('econom') || q.includes('couple') || q.includes('surf') || (passengers <= 2 && luggage <= 2)) {
        match = FLEET_CARS.find((c) => c.id === 'dacia-sandero') || match;
        rationale = 'At only 270 DH/day with exceptional 4.8L/100km diesel efficiency, the Dacia Sandero Stepway gives you elevated crossover ground clearance, Apple CarPlay, and the best price-to-comfort ratio in Morocco.';
        tips = [
          'Outstanding fuel economy lets you tour Morocco from Tangier to Essaouira with minimal fuel stops.',
          'Compact footprint makes parking near medina gates (e.g. Bab Doukkala in Marrakech) simple.',
        ];
      } else if (q.includes('family') || luggage >= 3) {
        match = FLEET_CARS.find((c) => c.id === 'dacia-logan') || match;
        rationale = 'The Dacia Logan boasts a monumental 528L trunk at just 280 DH/day, easily holding multiple large suitcases while delivering legendary Moroccan durability.';
        tips = [
          'Unmatched trunk space for souvenirs and oversized baggage.',
          'Very economical diesel engine with widespread serviceability everywhere in Morocco.',
        ];
      }

      setResult({
        recommendedCarId: match.id,
        carName: `${match.model} (${match.dailyRate} DH/day)`,
        rationale,
        itineraryTips: tips,
      });
    } finally {
      setLoading(false);
    }
  };

  const recommendedCar = result
    ? FLEET_CARS.find((c) => c.id === result.recommendedCarId)
    : null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-advisor-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 id="ai-advisor-title" className="text-base font-bold font-['Outfit']">
                YT-LOC Intelligent Route & Fleet Advisor
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>High-Reasoning Travel Intelligence</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400">Gemini Thinking Mode</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close advisor"
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Form */}
          <div className="space-y-4">
            <label htmlFor="ai-query-input" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Describe your Moroccan journey & group needs:
            </label>
            <div className="relative">
              <textarea
                id="ai-query-input"
                rows={3}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g. We are landing in Marrakech, spending 3 days exploring Ouarzazate, Dades Gorges and Merzouga dunes with 4 people and luggage. We want comfort and great ground clearance."
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all resize-none"
              />
            </div>

            {/* Quick Prompts */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-500 font-medium">Or choose a common Moroccan route:</span>
              <div className="flex flex-wrap gap-2">
                {quickPrompts.map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => {
                      setQuery(p);
                      handleRecommend(p);
                    }}
                    className="text-xs text-left bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200/80 rounded-xl px-3 py-1.5 transition-colors cursor-pointer"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Group Specs */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-1">
                <label htmlFor="ai-passengers" className="text-xs font-semibold text-slate-600 block">
                  Passengers
                </label>
                <select
                  id="ai-passengers"
                  value={passengers}
                  onChange={(e) => setPassengers(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 cursor-pointer"
                >
                  <option value={1}>1 Solo traveler</option>
                  <option value={2}>2 Passengers (Couple)</option>
                  <option value={3}>3 Passengers</option>
                  <option value={4}>4 Passengers (Family / Friends)</option>
                  <option value={5}>5 Passengers</option>
                </select>
              </div>

              <div className="space-y-1">
                <label htmlFor="ai-luggage" className="text-xs font-semibold text-slate-600 block">
                  Luggage & Bags
                </label>
                <select
                  id="ai-luggage"
                  value={luggage}
                  onChange={(e) => setLuggage(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 cursor-pointer"
                >
                  <option value={1}>1 Hand luggage</option>
                  <option value={2}>2 Medium suitcases</option>
                  <option value={3}>3 Medium-Large suitcases</option>
                  <option value={4}>4 Large suitcases + backpacks</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              disabled={loading || !query.trim()}
              onClick={() => handleRecommend()}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Analyzing Terrain & Calculating Fleet Fit...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Analyze Trip & Match Fleet</span>
                </>
              )}
            </button>
          </div>

          {/* Results Card */}
          {result && recommendedCar && (
            <div className="p-6 rounded-3xl bg-slate-50 border border-emerald-200 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-200">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
                    Recommended Match
                  </span>
                  <h3 className="text-2xl font-extrabold text-slate-950 font-['Outfit']">
                    {recommendedCar.name} ({recommendedCar.model})
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-slate-950 font-mono tabular-nums">
                    {recommendedCar.dailyRate} DH
                  </span>
                  <span className="text-xs text-slate-500 block">/ day</span>
                </div>
              </div>

              {/* Image */}
              <div className="aspect-[16/9] w-full max-h-48 bg-white rounded-2xl p-2 border border-slate-200/80 flex items-center justify-center overflow-hidden">
                <img
                  src={recommendedCar.image}
                  alt={recommendedCar.model}
                  className="h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Rationale */}
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Why this car fits your trip</span>
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {result.rationale}
                </p>
              </div>

              {/* Insider Tips */}
              {result.itineraryTips && result.itineraryTips.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-200/80">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                    <span>Moroccan Driving Tips for your route</span>
                  </h4>
                  <ul className="text-xs text-slate-600 space-y-1">
                    {result.itineraryTips.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">·</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectCar(recommendedCar);
                  }}
                  className="w-full py-3 px-4 bg-slate-950 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                >
                  <span>Select & Book {recommendedCar.model}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
