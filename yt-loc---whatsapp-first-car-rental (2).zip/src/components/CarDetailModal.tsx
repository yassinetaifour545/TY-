import React from 'react';
import { X, Check, Users, Gauge, Fuel, Briefcase, Wind, MessageCircle, ArrowRight } from 'lucide-react';
import { Car } from '../data/fleet';

interface CarDetailModalProps {
  car: Car | null;
  onClose: () => void;
  onBook: (car: Car) => void;
}

export const CarDetailModal: React.FC<CarDetailModalProps> = ({
  car,
  onClose,
  onBook,
}) => {
  if (!car) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="car-detail-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70 shrink-0">
          <div>
            <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider block">
              {car.category}
            </span>
            <h2 id="car-detail-title" className="text-xl font-bold text-slate-950 font-['Outfit']">
              {car.name} — {car.model}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close specifications"
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Image */}
          <div className="relative aspect-[16/10] w-full rounded-2xl bg-slate-50 border border-slate-200/80 p-4 flex items-center justify-center overflow-hidden">
            <img
              src={car.image}
              alt={car.model}
              className="max-h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Description & Recommended For */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-900">Vehicle Overview</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              {car.description}
            </p>
            <p className="text-xs text-emerald-800 font-medium bg-emerald-50/80 p-3 rounded-xl border border-emerald-100">
              💡 Recommended for: {car.recommendedFor}
            </p>
          </div>

          {/* Key Specs Grid */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Technical Specifications</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Seating Capacity</span>
                <span className="text-sm font-bold text-slate-900">{car.specs.seats} Adults</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Transmission</span>
                <span className="text-sm font-bold text-slate-900">{car.specs.transmission}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Fuel Type</span>
                <span className="text-sm font-bold text-slate-900">{car.specs.fuel}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Trunk Space</span>
                <span className="text-sm font-bold text-slate-900">{car.specs.luggage}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Fuel Consumption</span>
                <span className="text-sm font-bold text-slate-900">{car.specs.consumption}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <span className="text-[11px] text-slate-400 block font-medium">Air Conditioning</span>
                <span className="text-sm font-bold text-slate-900">Dual Zone / Climate A/C</span>
              </div>
            </div>
          </div>

          {/* Included Equipment */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Featured Features</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {car.features.map((feat) => (
                <div key={feat} className="flex items-center gap-2 text-xs text-slate-700">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div>
            <span className="text-xs text-slate-400 block">Daily Rental</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-950 font-mono tabular-nums">
                {car.dailyRate} DH
              </span>
              <span className="text-xs text-slate-500 font-semibold">/ day</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              onClose();
              onBook(car);
            }}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-sm rounded-xl flex items-center gap-2 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white text-white" />
            <span>Book this {car.model}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
