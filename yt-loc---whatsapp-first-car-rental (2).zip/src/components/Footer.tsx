import React, { useState } from 'react';
import { MessageCircle, Mail, Phone, MapPin, Shield, CheckCircle } from 'lucide-react';
import { CONTACT_INFO, FLEET_CARS } from '../data/fleet';

interface FooterProps {
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  const [modalType, setModalType] = useState<'terms' | 'privacy' | null>(null);

  return (
    <footer className="bg-slate-950 text-white pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black text-lg">
                YT
              </div>
              <span className="text-2xl font-black tracking-tight text-white font-['Outfit']">
                YT-LOC<span className="text-emerald-400">.</span>
              </span>
            </div>

            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              The modern, WhatsApp-first car rental agency in Morocco. Pristine fleet, transparent pricing in Dirhams, and instant human confirmation.
            </p>

            <div className="pt-2">
              <a
                href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I would like to inquire about car availability.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-colors shadow-sm"
              >
                <MessageCircle className="w-4 h-4 fill-slate-950 text-slate-950" />
                <span>WhatsApp: {CONTACT_INFO.whatsappRaw}</span>
              </a>
            </div>
          </div>

          {/* Contact Col */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Direct Contact
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`tel:+212${CONTACT_INFO.whatsappRaw.substring(1)}`}
                  className="hover:text-emerald-400 transition-colors font-mono"
                >
                  {CONTACT_INFO.whatsappDisplay} ({CONTACT_INFO.whatsappRaw})
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`mailto:${CONTACT_INFO.email}`}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {CONTACT_INFO.email}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Marrakech Menara Airport · Casablanca Mohammed V · Agadir
                </span>
              </li>
            </ul>
          </div>

          {/* Quick Fleet Col */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Fleet & Daily Rates
            </h4>
            <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs text-slate-400">
              {FLEET_CARS.map((car) => (
                <a
                  key={car.id}
                  href="#fleet"
                  className="hover:text-white transition-colors flex items-center justify-between"
                >
                  <span>{car.model}</span>
                  <span className="font-mono text-emerald-400">{car.dailyRate} DH</span>
                </a>
              ))}
            </div>
          </div>

          {/* Service Hubs Col */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Service Locations
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>Marrakech (RAK)</li>
              <li>Casablanca (CMN)</li>
              <li>Agadir (AGA)</li>
              <li>Tangier (TNG)</li>
              <li>Rabat-Salé (RBA)</li>
              <li>Fez-Saïss (FEZ)</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} YT-LOC Mobility Morocco. All rights reserved. Direct WhatsApp bookings via 0653134372.
          </div>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => setModalType('terms')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Terms & Conditions
            </button>
            <button
              type="button"
              onClick={() => setModalType('privacy')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsappInternational}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-emerald-400 transition-colors text-emerald-500"
            >
              WhatsApp Support
            </a>
          </div>
        </div>
      </div>

      {/* Terms & Conditions / Privacy Modal */}
      {modalType && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs"
        >
          <div className="bg-white text-slate-900 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base font-['Outfit']">
                {modalType === 'terms' ? 'Terms & Conditions' : 'Privacy Policy'}
              </h3>
              <button
                type="button"
                onClick={() => setModalType(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold p-1"
              >
                Close
              </button>
            </div>
            <div className="text-xs text-slate-600 space-y-3 leading-relaxed max-h-64 overflow-y-auto pr-2">
              {modalType === 'terms' ? (
                <>
                  <p>
                    <strong>1. Driver Requirements:</strong> Minimum driver age is 21 years. Valid national or international driving license held for at least 12 months is mandatory.
                  </p>
                  <p>
                    <strong>2. Pricing & Currency:</strong> All prices listed are quoted in Moroccan Dirhams (MAD/DH). Payment can be completed upon delivery in MAD, EUR, USD, or credit/debit card.
                  </p>
                  <p>
                    <strong>3. Fuel Policy:</strong> Vehicles are delivered with a set fuel level and returned with the same level (Like-for-Like).
                  </p>
                  <p>
                    <strong>4. Unlimited Mileage:</strong> Standard rentals include 100% unlimited mileage within the borders of the Kingdom of Morocco.
                  </p>
                  <p>
                    <strong>5. WhatsApp Concierge:</strong> All reservations agreed via WhatsApp at 0653134372 are legally binding once confirmed by our operations desk.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    <strong>1. Information Collection:</strong> We collect only the details necessary to prepare your vehicle rental agreement (Name, Phone number, Pick-up dates, Flight arrival).
                  </p>
                  <p>
                    <strong>2. WhatsApp Communication:</strong> Your contact number is used solely to coordinate vehicle handover, delivery logistics, and provide 24/7 customer assistance.
                  </p>
                  <p>
                    <strong>3. Data Security:</strong> We never sell or share your personal details with third-party advertising brokers. Contact details can be removed upon written request to contact.yass@gmail.com.
                  </p>
                </>
              )}
            </div>
            <button
              type="button"
              onClick={() => setModalType(null)}
              className="w-full py-2.5 bg-slate-950 text-white text-xs font-semibold rounded-xl hover:bg-slate-800 transition-colors"
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </footer>
  );
};
