import React, { useState, useEffect } from 'react';
import {
  X,
  MessageCircle,
  Calendar,
  MapPin,
  Clock,
  Shield,
  User,
  Phone,
  FileText,
  Copy,
  Check,
  ChevronRight,
  ChevronLeft,
  QrCode,
  Sparkles,
} from 'lucide-react';
import { Car, FLEET_CARS, MOROCCAN_LOCATIONS, CONTACT_INFO } from '../data/fleet';
import {
  AVAILABLE_EXTRAS,
  calculateDays,
  calculateBookingPrice,
  generateWhatsAppMessage,
  generateWhatsAppLink,
} from '../utils/pricing';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCar: Car;
  onSelectDifferentCar: (car: Car) => void;
  initialDate?: string;
  initialLocation?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  selectedCar,
  onSelectDifferentCar,
  initialDate,
  initialLocation,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Booking Form State
  const [startDate, setStartDate] = useState(() => {
    if (initialDate) return initialDate;
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });

  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 5);
    return d.toISOString().split('T')[0];
  });

  const [pickupLocation, setPickupLocation] = useState(
    initialLocation || MOROCCAN_LOCATIONS[0].name
  );
  const [dropoffLocation, setDropoffLocation] = useState(
    initialLocation || MOROCCAN_LOCATIONS[0].name
  );
  const [pickupTime, setPickupTime] = useState('10:00');
  const [dropoffTime, setDropoffTime] = useState('10:00');
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [flightOrNotes, setFlightOrNotes] = useState('');

  // UI state
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  // Sync if initial props change
  useEffect(() => {
    if (initialLocation) {
      setPickupLocation(initialLocation);
      setDropoffLocation(initialLocation);
    }
    if (initialDate) {
      setStartDate(initialDate);
    }
  }, [initialLocation, initialDate]);

  if (!isOpen) return null;

  const rentalDays = calculateDays(startDate, endDate);
  const pricing = calculateBookingPrice(
    selectedCar.dailyRate,
    rentalDays,
    selectedExtras,
    AVAILABLE_EXTRAS
  );

  const bookingData = {
    carModel: selectedCar.model,
    dailyRate: selectedCar.dailyRate,
    startDate,
    endDate,
    pickupLocation,
    dropoffLocation,
    pickupTime,
    dropoffTime,
    selectedExtras,
    customerName,
    customerPhone,
    flightOrNotes,
  };

  const whatsappMessage = generateWhatsAppMessage(bookingData, AVAILABLE_EXTRAS);
  const whatsappUrl = generateWhatsAppLink(
    CONTACT_INFO.whatsappInternational,
    bookingData,
    AVAILABLE_EXTRAS
  );

  const toggleExtra = (id: string) => {
    if (selectedExtras.includes(id)) {
      setSelectedExtras(selectedExtras.filter((item) => item !== id));
    } else {
      setSelectedExtras([...selectedExtras, id]);
    }
  };

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-950 text-emerald-400 flex items-center justify-center font-bold text-sm">
              YT
            </div>
            <div>
              <h2 id="booking-modal-title" className="text-base font-bold text-slate-900 font-['Outfit']">
                Book on WhatsApp with YT-LOC
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>Direct Concierge Confirmation</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-700 font-medium">WhatsApp: 0653134372</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close booking modal"
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Vehicle Banner */}
        <div className="px-6 py-3 bg-emerald-50/60 border-b border-emerald-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-16 h-10 bg-white rounded-lg p-1 border border-emerald-200/60 flex items-center justify-center overflow-hidden shrink-0">
              <img
                src={selectedCar.image}
                alt={selectedCar.model}
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider block">
                Selected Vehicle
              </span>
              <span className="text-sm font-bold text-slate-900">
                {selectedCar.model}
              </span>
              <span className="text-xs text-slate-500 ml-2">
                ({selectedCar.name})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-base font-extrabold text-slate-900 font-mono tabular-nums">
                {selectedCar.dailyRate} DH
              </span>
              <span className="text-[11px] text-slate-500 block">/ day</span>
            </div>
            <select
              aria-label="Switch selected car"
              value={selectedCar.id}
              onChange={(e) => {
                const found = FLEET_CARS.find((c) => c.id === e.target.value);
                if (found) onSelectDifferentCar(found);
              }}
              className="text-xs bg-white border border-emerald-200 rounded-lg px-2 py-1 font-medium text-slate-700 hover:border-emerald-400 focus:outline-none cursor-pointer"
            >
              {FLEET_CARS.map((c) => (
                <option key={c.id} value={c.id}>
                  Switch: {c.model} ({c.dailyRate} DH)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Step Progress Tabs */}
        <div className="px-6 py-3 border-b border-slate-100 bg-white flex items-center justify-between text-xs font-semibold shrink-0">
          <button
            type="button"
            onClick={() => setStep(1)}
            className={`flex items-center gap-1.5 pb-1 border-b-2 transition-colors cursor-pointer ${
              step === 1 ? 'border-slate-950 text-slate-950' : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            <span className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[10px]">1</span>
            <span>Dates & Locations</span>
          </button>
          <span className="text-slate-300">/</span>
          <button
            type="button"
            onClick={() => setStep(2)}
            className={`flex items-center gap-1.5 pb-1 border-b-2 transition-colors cursor-pointer ${
              step === 2 ? 'border-slate-950 text-slate-950' : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            <span className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[10px]">2</span>
            <span>Optional Extras</span>
          </button>
          <span className="text-slate-300">/</span>
          <button
            type="button"
            onClick={() => setStep(3)}
            className={`flex items-center gap-1.5 pb-1 border-b-2 transition-colors cursor-pointer ${
              step === 3 ? 'border-slate-950 text-slate-950' : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            <span className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[10px]">3</span>
            <span>Contact & WhatsApp</span>
          </button>
        </div>

        {/* Modal Body / Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* STEP 1: Dates & Locations */}
          {step === 1 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Pick-up Date */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-start-date" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Pick-up Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-start-date"
                      type="date"
                      value={startDate}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                {/* Drop-off Date */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-end-date" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Drop-off Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-end-date"
                      type="date"
                      value={endDate}
                      min={startDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                {/* Pick-up Location */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-pickup-loc" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Pick-up Location
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3 pointer-events-none" />
                    <select
                      id="modal-pickup-loc"
                      value={pickupLocation}
                      onChange={(e) => setPickupLocation(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    >
                      {MOROCCAN_LOCATIONS.map((loc) => (
                        <option key={loc.id} value={loc.name}>
                          {loc.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Drop-off Location */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-dropoff-loc" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Drop-off Location
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3 pointer-events-none" />
                    <select
                      id="modal-dropoff-loc"
                      value={dropoffLocation}
                      onChange={(e) => setDropoffLocation(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    >
                      {MOROCCAN_LOCATIONS.map((loc) => (
                        <option key={loc.id} value={loc.name}>
                          {loc.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Pick-up Time */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-pickup-time" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Pick-up Time
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-pickup-time"
                      type="time"
                      value={pickupTime}
                      onChange={(e) => setPickupTime(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* Drop-off Time */}
                <div className="space-y-1.5">
                  <label htmlFor="modal-dropoff-time" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Drop-off Time
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-dropoff-time"
                      type="time"
                      value={dropoffTime}
                      onChange={(e) => setDropoffTime(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Duration Preview Box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 block">Calculated Duration</span>
                  <span className="font-bold text-slate-900 text-sm">
                    {rentalDays} {rentalDays === 1 ? 'Day' : 'Days'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">Car Rental Subtotal</span>
                  <span className="font-bold text-slate-900 text-sm font-mono tabular-nums">
                    {pricing.carSubtotal} DH
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Optional Extras */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-900">
                  Select Optional Extras & Add-ons
                </h4>
                <p className="text-xs text-slate-500">
                  Custom extras for your Moroccan journey. All prices calculated daily per vehicle.
                </p>
              </div>

              <div className="space-y-3">
                {AVAILABLE_EXTRAS.map((extra) => {
                  const isChecked = selectedExtras.includes(extra.id);
                  const totalCost = extra.pricePerDay * rentalDays;
                  return (
                    <label
                      key={extra.id}
                      className={`flex items-start justify-between p-4 rounded-2xl border transition-all cursor-pointer ${
                        isChecked
                          ? 'border-emerald-600 bg-emerald-50/40 shadow-xs'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleExtra(extra.id)}
                          className="mt-1 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        />
                        <div>
                          <div className="text-sm font-bold text-slate-900">
                            {extra.name}
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5">
                            {extra.description}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0 ml-4">
                        <span className="text-xs font-bold text-slate-900 font-mono tabular-nums">
                          +{extra.pricePerDay} DH
                        </span>
                        <span className="text-[10px] text-slate-400 block">/ day</span>
                        <span className="text-[11px] text-emerald-700 font-medium font-mono tabular-nums block mt-1">
                          Total: +{totalCost} DH
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: Contact & WhatsApp Preview */}
          {step === 3 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-900">
                  Your Contact Details & WhatsApp Finalization
                </h4>
                <p className="text-xs text-slate-500">
                  Our concierge team will receive this exact message directly on WhatsApp to confirm availability immediately.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="modal-name" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Full Name <span className="text-emerald-600">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-name"
                      type="text"
                      placeholder="e.g. Yassine Alami"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="modal-phone" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    WhatsApp Phone Number <span className="text-emerald-600">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-phone"
                      type="tel"
                      placeholder="e.g. +212 653-134372"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2 space-y-1.5">
                  <label htmlFor="modal-notes" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Flight Number or Arrival Notes (Optional)
                  </label>
                  <div className="relative">
                    <FileText className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
                    <input
                      id="modal-notes"
                      type="text"
                      placeholder="e.g. Flight AT402 arriving 11:30 AM at Marrakech RAK"
                      value={flightOrNotes}
                      onChange={(e) => setFlightOrNotes(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Pre-formatted Message Preview */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700 uppercase tracking-wider">
                    Pre-filled WhatsApp Message
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="flex items-center gap-1 text-slate-600 hover:text-slate-950 font-medium cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Message</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-100/80 border border-slate-200 font-mono text-xs text-slate-700 whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed">
                  {whatsappMessage}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer & Price Summary */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 shrink-0 space-y-3">
          {/* Price Calculation Summary Strip */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500">
                {rentalDays} {rentalDays === 1 ? 'day' : 'days'} · {selectedCar.model}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xs text-slate-400">Total:</span>
                <span className="text-2xl font-black text-slate-950 font-mono tabular-nums">
                  {pricing.total} DH
                </span>
                <span className="text-xs font-semibold text-emerald-700">
                  (Zero hidden fees)
                </span>
              </div>
            </div>

            {/* Step navigation / Finalize on WhatsApp Button */}
            <div className="flex items-center gap-2">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep((step - 1) as any)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
              )}

              {step < 3 ? (
                <button
                  type="button"
                  onClick={() => setStep((step + 1) as any)}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl transition-all flex items-center gap-2 shadow-md shadow-emerald-600/25 whitespace-nowrap"
                >
                  <MessageCircle className="w-5 h-5 fill-white text-white" />
                  <span>Finalize Booking on WhatsApp</span>
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
