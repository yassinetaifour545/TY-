import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { CONTACT_INFO } from '../data/fleet';

export const FaqSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does booking via WhatsApp actually work?',
      a: 'It takes less than 2 minutes! Browse our fleet on this website, choose your dates, location, and extras. Click "Finalize Booking on WhatsApp". This automatically creates a pre-filled, perfectly formatted message on WhatsApp with your vehicle and price. Our concierge team receives it, immediately verifies vehicle availability, and sends you instant confirmation with meet-and-greet instructions.',
    },
    {
      q: 'What documents are required to rent a car in Morocco?',
      a: 'You will need a valid driver\'s license (held for at least 1 year) and your passport (or Moroccan CIN national ID). International driving permits are accepted but not mandatory for European, UK, US, or GCC licenses.',
    },
    {
      q: 'How does airport handover work at Marrakech (RAK) or Casablanca (CMN)?',
      a: 'We provide free airport meet-and-greet delivery. Our concierge tracks your flight in real-time. Once you exit baggage claim and pass customs into the arrivals hall, our representative will be waiting for you with your name board and the sanitized vehicle parked directly outside the terminal.',
    },
    {
      q: 'How do payments and deposits work? Are there hidden fees?',
      a: 'No hidden fees whatsoever! The daily rate displayed on our site in Moroccan Dirhams (DH) is the exact rate you pay. You pay upon vehicle delivery. We accept cash in Moroccan Dirhams (MAD), Euros (EUR), British Pounds (GBP), US Dollars (USD), or credit/debit card on portable terminal. A refundable security deposit is held and returned upon safe vehicle return.',
    },
    {
      q: 'Can I pick up the car in Marrakech and return it in Casablanca or Agadir?',
      a: 'Yes! We offer flexible one-way intercity rentals between major hubs including Marrakech, Casablanca, Agadir, Tangier, Rabat, and Fez. Mention your return city in the WhatsApp booking form and our concierge will coordinate the logistics.',
    },
    {
      q: 'Is mileage unlimited on Moroccan roads?',
      a: 'Yes, all rentals booked with YT-LOC include 100% unlimited mileage. Feel free to drive from the Atlantic surf coast to the dunes of Merzouga and the High Atlas summits without worrying about extra per-kilometer charges.',
    },
  ];

  return (
    <section id="faq" className="py-20 lg:py-28 bg-white border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-14">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
            <HelpCircle className="w-4 h-4 text-emerald-600" />
            <span>Frequently Asked Questions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-['Outfit']">
            Clear answers. Zero guesswork.
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            Everything you need to know about driving with YT-LOC in Morocco.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-50/50 transition-colors"
              >
                <button
                  type="button"
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-slate-900 font-['Outfit'] text-base hover:text-emerald-800 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-emerald-600' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-sm text-slate-600 leading-relaxed border-t border-slate-200/60 pt-3 bg-white">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-12 p-6 rounded-3xl bg-emerald-50/80 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-bold text-slate-900">
              Have a custom request or specific route inquiry?
            </h4>
            <p className="text-xs text-slate-600 mt-0.5">
              Our concierge is ready to assist you directly on WhatsApp.
            </p>
          </div>
          <a
            href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I have a question about car rental in Morocco.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-2 whitespace-nowrap transition-colors"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Chat on WhatsApp: 0653134372</span>
          </a>
        </div>
      </div>
    </section>
  );
};
