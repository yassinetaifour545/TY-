import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Zap, Sparkles, MapPin, Calendar, Car as CarIcon, MessageCircle } from 'lucide-react';
import { MOROCCAN_LOCATIONS, FLEET_CARS, CONTACT_INFO, Car } from '../data/fleet';

interface HeroProps {
  onSelectCarToBook: (car: Car, initialDate?: string, location?: string) => void;
  onOpenAiAdvisor: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSelectCarToBook, onOpenAiAdvisor }) => {
  const [selectedLocation, setSelectedLocation] = useState(MOROCCAN_LOCATIONS[0].name);
  const [selectedCarId, setSelectedCarId] = useState(FLEET_CARS[0].id);
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 5);
    return d.toISOString().split('T')[0];
  });

  const activeCar = FLEET_CARS.find((c) => c.id === selectedCarId) || FLEET_CARS[0];

  const handleStartBooking = () => {
    onSelectCarToBook(activeCar, startDate, selectedLocation);
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-slate-50/50 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main 2-column Hero split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Typography & Intent */}
          <div className="lg:col-span-7 space-y-6">
            {/* Quiet text kicker with typographic separator (Zero-pill discipline) */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
              <span>YT-LOC Mobility</span>
              <span aria-hidden="true" className="text-slate-400">·</span>
              <span>WhatsApp-First Service</span>
              <span aria-hidden="true" className="text-slate-400">·</span>
              <span>Free Airport Delivery</span>
            </div>

            {/* Headline with text-wrap: balance */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-950 font-['Outfit'] leading-[1.08] [text-wrap:balance]">
              Rent the car you <span className="text-emerald-700 underline decoration-emerald-200 decoration-4 underline-offset-8">actually want</span> to drive.
            </h1>

            {/* Sub-headline */}
            <p className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed max-w-2xl">
              Experience the easiest car rental in Morocco. Browse our curated, pristine fleet online and confirm your booking in minutes directly on WhatsApp with our local team. No hidden fees, no hold music.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href="#fleet"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-base font-semibold text-white bg-slate-950 rounded-xl hover:bg-slate-800 active:scale-95 transition-all shadow-md shadow-slate-950/10"
              >
                <span>Explore the Fleet</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href="#how-it-works"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 hover:text-slate-950 transition-colors"
              >
                <span>How It Works</span>
              </a>

              <button
                type="button"
                onClick={onOpenAiAdvisor}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors border border-emerald-200/60"
              >
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>AI Route Recommender</span>
              </button>
            </div>

            {/* 3 Trust Markers in quiet inline typography */}
            <div className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Zero Hidden Fees Guaranteed</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-500" />
                <span>Instant Confirmation on WhatsApp</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>Marrakech · Casablanca · Agadir</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Vehicle Showcase (Single dominant focal carrier) */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl bg-slate-100/80 p-6 sm:p-8 border border-slate-200/90 shadow-sm overflow-hidden">
              {/* Subtle background glow */}
              <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-200/40 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                      Flagship Feature
                    </span>
                    <h3 className="text-2xl font-bold text-slate-950 font-['Outfit']">
                      Volkswagen T-Roc
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">Daily rate</span>
                    <span className="text-2xl font-extrabold text-slate-950 font-mono tabular-nums">
                      600 DH
                    </span>
                    <span className="text-xs text-slate-500 font-medium"> / day</span>
                  </div>
                </div>

                {/* Car Image with robust fallback */}
                <div className="relative aspect-[16/10] w-full rounded-2xl bg-white flex items-center justify-center p-2 overflow-hidden border border-slate-200/60 shadow-inner">
                  <img
                    src="/assets/aistudio/Gemini_Generated_Image_wa4n4gwa4n4gwa4n_687e4be0.jpg"
                    alt="Volkswagen T-Roc at YT-LOC Car Rental"
                    className="w-full h-full object-contain hover:scale-105 transition-transform duration-500"
                    loading="eager"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Transmission</span>
                    <span className="font-semibold text-slate-800">DSG Automatic</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Fuel Economy</span>
                    <span className="font-semibold text-slate-800">5.1L / 100km</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/70">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Capacity</span>
                    <span className="font-semibold text-slate-800">5 Seats · 445L</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectCarToBook(FLEET_CARS.find((c) => c.id === 'vw-t-roc')!)}
                  className="w-full mt-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm shadow-emerald-600/20 transition-all"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>Reserve VW T-Roc on WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 4-column Fast Rental Configurator Strip in a full-width row below hero split */}
        <div className="mt-12 lg:mt-16 bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            {/* 1. Pick-up Location */}
            <div className="space-y-1.5">
              <label htmlFor="hero-location" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Pick-up & Drop-off
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3.5 pointer-events-none" />
                <select
                  id="hero-location"
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all cursor-pointer"
                >
                  {MOROCCAN_LOCATIONS.map((loc) => (
                    <option key={loc.id} value={loc.name}>
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 2. Pick-up Date */}
            <div className="space-y-1.5">
              <label htmlFor="hero-start-date" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Pick-up Date
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                <input
                  id="hero-start-date"
                  type="date"
                  value={startDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all cursor-pointer"
                />
              </div>
            </div>

            {/* 3. Choose Car Model */}
            <div className="space-y-1.5">
              <label htmlFor="hero-car" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Select Model
              </label>
              <div className="relative">
                <CarIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                <select
                  id="hero-car"
                  value={selectedCarId}
                  onChange={(e) => setSelectedCarId(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all cursor-pointer"
                >
                  {FLEET_CARS.map((car) => (
                    <option key={car.id} value={car.id}>
                      {car.model} ({car.dailyRate} DH/day)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 4. Action Button */}
            <div>
              <button
                type="button"
                onClick={handleStartBooking}
                className="w-full py-2.5 px-5 bg-slate-950 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 transition-colors shadow-sm"
              >
                <span>Continue to Booking</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
