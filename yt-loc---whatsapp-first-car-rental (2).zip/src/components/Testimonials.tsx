import React from 'react';
import { Star, MessageCircle, CheckCircle2 } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: 'Dr. Julien Fournier',
      origin: 'Paris, France',
      trip: 'Marrakech to Ouarzazate & Merzouga',
      car: 'Hyundai Tucson (450 DH/day)',
      rating: 5,
      date: 'October 2026',
      content:
        'Booking on WhatsApp with YT-LOC was an absolute breath of fresh air. I sent my dates, they confirmed in less than 3 minutes, and met me right outside Marrakech Menara arrivals gate with the Tucson. Spotless car, crystal clear contract with zero hidden charges. Will book again in December!',
    },
    {
      name: 'Sofia Martinez',
      origin: 'Madrid, Spain',
      trip: 'Marrakech & Essaouira Coast',
      car: 'Dacia Sandero Stepway (270 DH/day)',
      rating: 5,
      date: 'September 2026',
      content:
        'The 270 DH per day for the Sandero is unbelievable value. We drove all the way to Taghazout and Essaouira. Fuel economy was great and chatting with the team on WhatsApp anytime we had a parking question in the Medina made us feel totally looked after.',
    },
    {
      name: 'Mehdi Benjelloun',
      origin: 'Casablanca, Morocco',
      trip: 'Casablanca to Tangier Business Run',
      car: 'VW T-Roc (600 DH/day)',
      rating: 5,
      date: 'October 2026',
      content:
        'Needed a reliable executive SUV for a high-profile corporate client visiting Casablanca. The VW T-Roc was in mint condition, clean DSG transmission, and handover was smooth right at the hotel entrance. YT-LOC sets a new gold standard for Moroccan car rental.',
    },
    {
      name: 'Oliver & Emma Smith',
      origin: 'London, UK',
      trip: 'Atlas Mountain Expedition',
      car: 'Renault Clio 5 (300 DH/day)',
      rating: 5,
      date: 'August 2026',
      content:
        'No waiting in airport counter queues with hungry kids! We landed, texted on WhatsApp, and the car was waiting outside. Child safety seats were already securely installed. The Clio 5 handled the mountain switchbacks smoothly. 10/10 service!',
    },
  ];

  return (
    <section id="testimonials" className="py-20 lg:py-28 bg-slate-50/70 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
            <span>Verified Client Feedback</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>4.9 / 5.0 Rating</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-['Outfit']">
            Trusted by travelers across Morocco
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            Real experiences from travelers who booked in minutes directly on WhatsApp and enjoyed hassle-free journeys across the Kingdom.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-14">
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
            >
              <div className="space-y-3">
                {/* Stars and WhatsApp badge */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                    <MessageCircle className="w-3.5 h-3.5 fill-emerald-600 text-emerald-600" />
                    <span>WhatsApp Verified</span>
                  </div>
                </div>

                {/* Review Text */}
                <p className="text-slate-700 text-sm leading-relaxed italic">
                  "{rev.content}"
                </p>
              </div>

              {/* Author & Journey Info */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-900 block text-sm">
                    {rev.name}
                  </span>
                  <span className="text-slate-500">
                    {rev.origin} · {rev.trip}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-semibold text-slate-800 block">
                    {rev.car}
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    {rev.date}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
