import React, { useState } from 'react';
import { MessageCircle, X, ChevronRight, Sparkles } from 'lucide-react';
import { CONTACT_INFO } from '../data/fleet';

interface FloatingWhatsAppProps {
  onOpenBooking: () => void;
  onOpenAiAdvisor: () => void;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({
  onOpenBooking,
  onOpenAiAdvisor,
}) => {
  const [showPopup, setShowPopup] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Quick Action Concierge Card */}
      {showPopup && (
        <div className="mb-4 w-72 sm:w-80 bg-white rounded-3xl p-5 shadow-2xl border border-slate-200/90 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                YT
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 font-['Outfit']">
                  YT-LOC Concierge
                </h4>
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-700 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Online · Ready on WhatsApp</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowPopup(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              aria-label="Close concierge popup"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-slate-600 my-3 leading-relaxed">
            Need an instant quote or fast car confirmation? Message us directly or configure your trip on-site.
          </p>

          <div className="space-y-2">
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I have an inquiry about renting a car in Morocco.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl flex items-center justify-between transition-colors shadow-xs"
            >
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 fill-white text-white" />
                <span>Chat: {CONTACT_INFO.whatsappRaw}</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </a>

            <button
              type="button"
              onClick={() => {
                setShowPopup(false);
                onOpenBooking();
              }}
              className="w-full py-2 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl flex items-center justify-between transition-colors cursor-pointer"
            >
              <span>Custom Booking Calculator</span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>
      )}

      {/* Persistent Floating WhatsApp Button */}
      <div className="relative group">
        {/* Subtle non-intrusive animated pulse wave */}
        <span className="absolute -inset-1 rounded-full bg-emerald-500/30 animate-ping pointer-events-none" />

        <button
          type="button"
          onClick={() => setShowPopup(!showPopup)}
          aria-label="Chat with YT-LOC on WhatsApp: 0653134372"
          className="relative flex items-center gap-2.5 px-4 py-3 sm:px-5 sm:py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-lg shadow-emerald-700/30 transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
        >
          <MessageCircle className="w-6 h-6 fill-white text-white shrink-0" />
          <span className="hidden sm:inline text-xs font-bold tracking-tight">
            WhatsApp: {CONTACT_INFO.whatsappRaw}
          </span>
        </button>
      </div>
    </div>
  );
};
