import React, { useState } from 'react';
import { Users, Fuel, Briefcase, Gauge, MessageCircle, Info } from 'lucide-react';
import { Car } from '../data/fleet';

interface CarCardProps {
  car: Car;
  onBook: (car: Car) => void;
  onViewDetails: (car: Car) => void;
}

export const CarCard: React.FC<CarCardProps> = ({ car, onBook, onViewDetails }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <article className="group relative bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between">
      {/* Top Header & Price */}
      <div className="p-6 pb-2">
        <div className="flex items-start justify-between gap-4">
          <div>
            {/* Unboxed category & editorial kicker */}
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <span>{car.category}</span>
              {car.badge && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-emerald-700 font-semibold">{car.badge}</span>
                </>
              )}
            </div>
            {/* Lifestyle creative name */}
            <h3 className="text-xl font-bold text-slate-950 font-['Outfit'] mt-1 group-hover:text-emerald-800 transition-colors">
              {car.name}
            </h3>
            {/* Exact Official Car Model */}
            <p className="text-sm font-semibold text-slate-600">
              {car.model}
            </p>
          </div>

          {/* Daily Price */}
          <div className="text-right shrink-0">
            <span className="text-xs text-slate-400 uppercase font-semibold block">Rate</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-extrabold text-slate-950 font-mono tabular-nums">
                {car.dailyRate}
              </span>
              <span className="text-xs font-bold text-slate-500">DH</span>
            </div>
            <span className="text-[11px] text-slate-400">/ day</span>
          </div>
        </div>

        {/* 1-line benefit description */}
        <p className="text-xs text-slate-600 line-clamp-2 mt-2 leading-relaxed">
          {car.tagline}
        </p>
      </div>

      {/* Car Visual Image Container */}
      <div className="relative aspect-[16/10] w-full px-4 py-2 bg-gradient-to-b from-transparent to-slate-50/70 flex items-center justify-center overflow-hidden">
        {!imgError ? (
          <img
            src={car.image}
            alt={`${car.model} - ${car.name}`}
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 rounded-2xl text-slate-400 p-4">
            <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center mb-2">
              <Gauge className="w-6 h-6 text-slate-500" />
            </div>
            <span className="text-xs font-semibold text-slate-600">{car.model}</span>
            <span className="text-[10px] text-slate-400">Modern Fleet Moroccan Studio</span>
          </div>
        )}
      </div>

      {/* Unboxed Metadata Specs Line (Strict Zero-Pill Discipline) */}
      <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/40">
        <div className="flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-1.5" title="Passenger Capacity">
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <span>{car.specs.seats} Seats</span>
          </div>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <div className="flex items-center gap-1.5" title="Transmission">
            <Gauge className="w-3.5 h-3.5 text-slate-400" />
            <span>{car.specs.transmission}</span>
          </div>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <div className="flex items-center gap-1.5" title="Fuel Engine">
            <Fuel className="w-3.5 h-3.5 text-slate-400" />
            <span>{car.specs.fuel}</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-6 pt-3 border-t border-slate-100 flex items-center gap-2">
        <button
          type="button"
          onClick={() => onBook(car)}
          aria-label={`Book ${car.model} via WhatsApp`}
          className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-semibold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm shadow-emerald-600/20 transition-all cursor-pointer"
        >
          <MessageCircle className="w-4 h-4 fill-white" />
          <span>Book Now</span>
        </button>

        <button
          type="button"
          onClick={() => onViewDetails(car)}
          aria-label={`View full specifications for ${car.model}`}
          className="p-3 text-slate-600 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          title="Vehicle details & luggage specs"
        >
          <Info className="w-4 h-4" />
        </button>
      </div>
    </article>
  );
};
