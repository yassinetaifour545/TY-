import React, { useState } from 'react';
import { MessageCircle, Menu, X, Car as CarIcon, Shield, Sparkles } from 'lucide-react';
import { CONTACT_INFO } from '../data/fleet';

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenAiAdvisor: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking, onOpenAiAdvisor }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Brand Wordmark (Strict single-element wordmark) */}
          <a
            href="/"
            className="flex items-center gap-2.5 text-2xl font-extrabold tracking-tight text-slate-950 font-['Outfit'] whitespace-nowrap shrink-0 group"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-950 text-emerald-400 flex items-center justify-center font-bold text-lg shadow-sm group-hover:bg-emerald-900 transition-colors">
              YT
            </div>
            <div className="flex flex-col">
              <span className="leading-none text-xl font-bold tracking-tight">
                YT-LOC<span className="text-emerald-600">.</span>
              </span>
              <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-500">
                DriveEase Morocco
              </span>
            </div>
          </a>

          {/* Zone 2: 4-5 single-line clean navigation links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a
              href="#fleet"
              className="hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Our Fleet
            </a>
            <a
              href="#how-it-works"
              className="hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              How It Works
            </a>
            <a
              href="#why-choose-us"
              className="hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Why Choose Us
            </a>
            <a
              href="#testimonials"
              className="hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              Reviews
            </a>
            <a
              href="#faq"
              className="hover:text-slate-950 transition-colors whitespace-nowrap shrink-0 py-1"
            >
              FAQ
            </a>
            <button
              onClick={onOpenAiAdvisor}
              className="flex items-center gap-1.5 text-emerald-700 hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0 font-semibold"
            >
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>AI Trip Advisor</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I have an inquiry about renting a car.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 active:scale-95 transition-all shadow-sm shadow-emerald-600/20 whitespace-nowrap shrink-0"
            >
              <MessageCircle className="w-4 h-4 fill-white text-white" />
              <span>WhatsApp: 0653134372</span>
            </a>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsappInternational}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Direct WhatsApp Chat"
              className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg"
            >
              <MessageCircle className="w-6 h-6 fill-emerald-600" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <a
            href="#fleet"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
          >
            Our Fleet (8 Vehicles)
          </a>
          <a
            href="#how-it-works"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
          >
            How It Works
          </a>
          <a
            href="#why-choose-us"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
          >
            Why Choose Us
          </a>
          <a
            href="#testimonials"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
          >
            Client Reviews
          </a>
          <a
            href="#faq"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-800 hover:bg-slate-50 rounded-lg"
          >
            FAQ & Requirements
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenAiAdvisor();
            }}
            className="w-full text-left flex items-center gap-2 px-3 py-2 text-base font-medium text-emerald-700 hover:bg-emerald-50 rounded-lg"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Moroccan Route & Car Advisor</span>
          </button>
          <div className="pt-2">
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsappInternational}?text=${encodeURIComponent('Hello YT-LOC! I want to book a car via WhatsApp.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition-colors"
            >
              <MessageCircle className="w-5 h-5 fill-white text-white" />
              <span>Book via WhatsApp: 0653134372</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
