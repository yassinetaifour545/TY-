import React, { useState } from 'react';
import { FLEET_CARS, Car } from '../data/fleet';
import { CarCard } from './CarCard';
import { Sparkles, SlidersHorizontal, Check } from 'lucide-react';

interface FleetSectionProps {
  onSelectCarToBook: (car: Car) => void;
  onViewDetails: (car: Car) => void;
  onOpenAiAdvisor: () => void;
}

export const FleetSection: React.FC<FleetSectionProps> = ({
  onSelectCarToBook,
  onViewDetails,
  onOpenAiAdvisor,
}) => {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Compact & City' | 'SUV & Crossover' | 'Premium & SUV'>('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'price-asc' | 'price-desc'>('recommended');

  const filteredCars = FLEET_CARS.filter((car) => {
    if (activeCategory === 'All') return true;
    return car.category === activeCategory;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.dailyRate - b.dailyRate;
    if (sortBy === 'price-desc') return b.dailyRate - a.dailyRate;
    return 0; // default curated order
  });

  return (
    <section id="fleet" className="py-20 lg:py-28 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-slate-100">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
              <span>Curated Fleet</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>8 Selected Models</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>Direct WhatsApp Handover</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-950 font-['Outfit']">
              The Fleet. Handpicked for Moroccan Roads.
            </h2>
            <p className="text-slate-600 text-base leading-relaxed">
              Every vehicle is owned, fully insured, meticulously sanitized, and ready for departure from Marrakech, Casablanca, or Agadir. All prices are in Moroccan Dirhams (DH) with zero hidden fees.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenAiAdvisor}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-xl transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Not sure which car? Ask AI Advisor</span>
            </button>
          </div>
        </div>

        {/* Filter Bar: Segmented controls (Allowed interactive button tabs per Section 1A) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-6">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl w-fit">
            {(['All', 'Compact & City', 'SUV & Crossover', 'Premium & SUV'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === cat
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950 hover:bg-white/50'
                }`}
              >
                {cat === 'All' ? 'All Vehicles (8)' : cat}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span className="font-medium text-slate-500">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="recommended">Featured Fleet Order</option>
              <option value="price-asc">Price: Low to High (270 DH → 600 DH)</option>
              <option value="price-desc">Price: High to Low (600 DH → 270 DH)</option>
            </select>
          </div>
        </div>

        {/* Cars Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-4">
          {filteredCars.map((car) => (
            <CarCard
              key={car.id}
              car={car}
              onBook={onSelectCarToBook}
              onViewDetails={onViewDetails}
            />
          ))}
        </div>

        {/* Transparent Fleet Inclusions Banner */}
        <div className="mt-16 p-6 sm:p-8 rounded-3xl bg-slate-50 border border-slate-200/80">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Unlimited Mileage</span>
              </h4>
              <p className="text-xs text-slate-500">
                Explore Morocco from the Atlantic to the Sahara without mileage caps.
              </p>
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Comprehensive Insurance</span>
              </h4>
              <p className="text-xs text-slate-500">
                Third-party liability & collision protection included on all rentals.
              </p>
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>24/7 Roadside Assistance</span>
              </h4>
              <p className="text-xs text-slate-500">
                Round-the-clock mechanical support anywhere along your journey.
              </p>
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Free Airport Meet & Greet</span>
              </h4>
              <p className="text-xs text-slate-500">
                We meet you right at terminal arrivals with keys and paperwork ready.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
