export interface ExtraItem {
  id: string;
  name: string;
  pricePerDay: number; // in DH
  icon?: string;
  description: string;
}

export interface BookingDetails {
  carModel: string;
  dailyRate: number; // in DH
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  pickupLocation: string;
  dropoffLocation: string;
  pickupTime: string;
  dropoffTime: string;
  selectedExtras: string[]; // array of ExtraItem ids
  customerName: string;
  customerPhone: string;
  flightOrNotes?: string;
}

export const AVAILABLE_EXTRAS: ExtraItem[] = [
  {
    id: 'additional-driver',
    name: 'Additional Driver',
    pricePerDay: 50,
    description: 'Share the driving duties across Moroccan scenic routes.',
  },
  {
    id: 'child-seat',
    name: 'Child Safety Seat',
    pricePerDay: 40,
    description: 'Certified ISOFIX ergonomic child or infant booster seat.',
  },
  {
    id: 'full-insurance',
    name: 'Full Zero-Deductible Protection',
    pricePerDay: 70,
    description: 'Complete peace of mind covering tires, glass, and scratches.',
  },
  {
    id: 'wifi-gps',
    name: '4G WiFi Hotspot & GPS Navigation',
    pricePerDay: 35,
    description: 'Unlimited high-speed internet connectivity across Morocco.',
  },
];

/**
 * Calculates rental duration in whole days (minimum 1 day).
 */
export function calculateDays(startDate: string, endDate: string): number {
  if (!startDate || !endDate) return 1;
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    return 1;
  }
  
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays : 1;
}

/**
 * Calculates itemized total cost in Moroccan Dirhams (DH / MAD).
 */
export function calculateBookingPrice(
  dailyRate: number,
  days: number,
  selectedExtraIds: string[],
  availableExtras: ExtraItem[] = AVAILABLE_EXTRAS
): {
  days: number;
  carSubtotal: number;
  extrasSubtotal: number;
  extrasBreakdown: { name: string; cost: number; rate: number }[];
  total: number;
} {
  const safeDays = Math.max(1, days);
  const carSubtotal = dailyRate * safeDays;
  
  const extrasBreakdown = selectedExtraIds
    .map((id) => {
      const extra = availableExtras.find((e) => e.id === id);
      if (!extra) return null;
      return {
        name: extra.name,
        rate: extra.pricePerDay,
        cost: extra.pricePerDay * safeDays,
      };
    })
    .filter((item): item is { name: string; cost: number; rate: number } => item !== null);

  const extrasSubtotal = extrasBreakdown.reduce((sum, item) => sum + item.cost, 0);
  const total = carSubtotal + extrasSubtotal;

  return {
    days: safeDays,
    carSubtotal,
    extrasSubtotal,
    extrasBreakdown,
    total,
  };
}

/**
 * Normalizes phone number into international WhatsApp wa.me format (+212 Morocco).
 */
export function formatWhatsAppPhoneNumber(phone: string): string {
  const clean = phone.replace(/[^\d+]/g, '');
  if (clean.startsWith('+')) {
    return clean.substring(1);
  }
  if (clean.startsWith('00')) {
    return clean.substring(2);
  }
  if (clean.startsWith('0')) {
    // Moroccan local number 06... -> 2126...
    return '212' + clean.substring(1);
  }
  if (clean.startsWith('212')) {
    return clean;
  }
  return clean || '212653134372';
}

/**
 * Constructs the clean, professional pre-filled WhatsApp message.
 */
export function generateWhatsAppMessage(
  booking: BookingDetails,
  extrasList: ExtraItem[] = AVAILABLE_EXTRAS
): string {
  const days = calculateDays(booking.startDate, booking.endDate);
  const price = calculateBookingPrice(booking.dailyRate, days, booking.selectedExtras, extrasList);
  
  const extrasNames = booking.selectedExtras
    .map((id) => extrasList.find((e) => e.id === id)?.name)
    .filter(Boolean)
    .join(', ');

  const extrasText = extrasNames.length > 0 ? extrasNames : 'None (Standard included package)';

  return [
    `Hello YT-LOC! 👋 I would like to book a car rental.`,
    ``,
    `🚘 Vehicle: ${booking.carModel} (${booking.dailyRate} DH/day)`,
    `📅 Dates: ${booking.startDate} to ${booking.endDate} (${days} ${days === 1 ? 'day' : 'days'})`,
    `📍 Pick-up: ${booking.pickupLocation || 'Marrakech Airport'} at ${booking.pickupTime || '10:00'}`,
    `🏁 Drop-off: ${booking.dropoffLocation || 'Marrakech Airport'} at ${booking.dropoffTime || '10:00'}`,
    `✨ Extras: ${extrasText}`,
    `💰 Estimated Total: ${price.total} DH (Dirhams)`,
    ``,
    `👤 Customer Name: ${booking.customerName || '[Not provided]'}`,
    `📞 Phone / WhatsApp: ${booking.customerPhone || '[Not provided]'}`,
    booking.flightOrNotes ? `📝 Flight/Notes: ${booking.flightOrNotes}` : null,
    ``,
    `Please confirm vehicle availability and reservation details. Thank you!`,
  ]
    .filter((line) => line !== null)
    .join('\n');
}

/**
 * Generates the full wa.me link with encoded text.
 */
export function generateWhatsAppLink(
  phoneNumber: string,
  booking: BookingDetails,
  extrasList: ExtraItem[] = AVAILABLE_EXTRAS
): string {
  const cleanPhone = formatWhatsAppPhoneNumber(phoneNumber);
  const message = generateWhatsAppMessage(booking, extrasList);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}
