import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDays,
  calculateBookingPrice,
  formatWhatsAppPhoneNumber,
  generateWhatsAppMessage,
  generateWhatsAppLink,
} from './pricing';

test('calculateDays handles normal dates and same-day bounds', () => {
  assert.equal(calculateDays('2026-11-01', '2026-11-05'), 4);
  assert.equal(calculateDays('2026-11-01', '2026-11-01'), 1); // minimum 1 day
  assert.equal(calculateDays('2026-11-05', '2026-11-01'), 1); // edge inverted fallback
  assert.equal(calculateDays('', ''), 1);
});

test('calculateBookingPrice calculates correct DH subtotal and extras', () => {
  // Test Dacia Sandero (270 DH) for 3 days without extras
  const calc1 = calculateBookingPrice(270, 3, []);
  assert.equal(calc1.days, 3);
  assert.equal(calc1.carSubtotal, 810);
  assert.equal(calc1.extrasSubtotal, 0);
  assert.equal(calc1.total, 810);

  // Test VW T-Roc (600 DH) for 5 days with additional driver (50 DH/day) and child seat (40 DH/day)
  // Car: 600 * 5 = 3000
  // Extras: (50 + 40) * 5 = 450
  // Total: 3450 DH
  const calc2 = calculateBookingPrice(600, 5, ['additional-driver', 'child-seat']);
  assert.equal(calc2.carSubtotal, 3000);
  assert.equal(calc2.extrasSubtotal, 450);
  assert.equal(calc2.total, 3450);
});

test('formatWhatsAppPhoneNumber converts Moroccan local numbers to +212 format', () => {
  assert.equal(formatWhatsAppPhoneNumber('0653134372'), '212653134372');
  assert.equal(formatWhatsAppPhoneNumber('+212 653 134 372'), '212653134372');
  assert.equal(formatWhatsAppPhoneNumber('00212653134372'), '212653134372');
});

test('generateWhatsAppMessage contains key details and price in DH', () => {
  const message = generateWhatsAppMessage({
    carModel: 'Peugeot 208',
    dailyRate: 320,
    startDate: '2026-11-10',
    endDate: '2026-11-14',
    pickupLocation: 'Marrakech Menara Airport',
    dropoffLocation: 'Marrakech Menara Airport',
    pickupTime: '11:00',
    dropoffTime: '11:00',
    selectedExtras: ['additional-driver'],
    customerName: 'Yassine',
    customerPhone: '0653134372',
    flightOrNotes: 'Flight AT402 arriving 10:30',
  });

  assert.match(message, /Peugeot 208/);
  assert.match(message, /320 DH\/day/);
  assert.match(message, /Marrakech Menara Airport/);
  assert.match(message, /Yassine/);
  assert.match(message, /Estimated Total: 1480 DH/); // 320*4 + 50*4 = 1280 + 200 = 1480
});

test('generateWhatsAppLink returns valid wa.me URL with phone 212653134372', () => {
  const link = generateWhatsAppLink('0653134372', {
    carModel: 'Dacia Logan',
    dailyRate: 280,
    startDate: '2026-11-01',
    endDate: '2026-11-03',
    pickupLocation: 'Casablanca Airport',
    dropoffLocation: 'Casablanca Airport',
    pickupTime: '14:00',
    dropoffTime: '14:00',
    selectedExtras: [],
    customerName: 'Karim',
    customerPhone: '0612345678',
  });

  assert.ok(link.startsWith('https://wa.me/212653134372?text='));
  assert.ok(link.includes(encodeURIComponent('Dacia Logan')));
  assert.ok(link.includes(encodeURIComponent('560 DH'))); // 280 * 2 days
});
