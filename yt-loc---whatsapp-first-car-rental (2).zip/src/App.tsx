import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FleetSection } from './components/FleetSection';
import { HowItWorks } from './components/HowItWorks';
import { WhyChooseUs } from './components/WhyChooseUs';
import { Testimonials } from './components/Testimonials';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { BookingModal } from './components/BookingModal';
import { CarDetailModal } from './components/CarDetailModal';
import { AiAdvisorModal } from './components/AiAdvisorModal';
import { FLEET_CARS, Car } from './data/fleet';

export default function App() {
  const [selectedCarForBooking, setSelectedCarForBooking] = useState<Car>(FLEET_CARS[0]);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingInitialDate, setBookingInitialDate] = useState<string | undefined>();
  const [bookingInitialLocation, setBookingInitialLocation] = useState<string | undefined>();

  const [detailedCar, setDetailedCar] = useState<Car | null>(null);
  const [isAiAdvisorOpen, setIsAiAdvisorOpen] = useState(false);

  const handleOpenBooking = (car?: Car, date?: string, location?: string) => {
    if (car) setSelectedCarForBooking(car);
    if (date) setBookingInitialDate(date);
    if (location) setBookingInitialLocation(location);
    setIsBookingOpen(true);
  };

  const handleSelectDifferentCar = (car: Car) => {
    setSelectedCarForBooking(car);
  };

  const handleExploreFleet = () => {
    const el = document.getElementById('fleet');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-['Plus_Jakarta_Sans',sans-serif] antialiased selection:bg-emerald-100 selection:text-emerald-900 flex flex-col justify-between">
      {/* Navigation */}
      <Navbar
        onOpenBooking={() => handleOpenBooking()}
        onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onSelectCarToBook={(car, date, loc) => handleOpenBooking(car, date, loc)}
          onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
        />

        {/* Fleet Showcase (All 8 Vehicles with exact DH prices) */}
        <FleetSection
          onSelectCarToBook={(car) => handleOpenBooking(car)}
          onViewDetails={(car) => setDetailedCar(car)}
          onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
        />

        {/* How It Works (3 Steps) */}
        <HowItWorks onExploreFleet={handleExploreFleet} />

        {/* Why Choose Us (Split Layout) */}
        <WhyChooseUs />

        {/* Client Reviews */}
        <Testimonials />

        {/* FAQ Section */}
        <FaqSection />
      </main>

      {/* Footer */}
      <Footer onOpenBooking={() => handleOpenBooking()} />

      {/* Persistent Floating WhatsApp Concierge Button */}
      <FloatingWhatsApp
        onOpenBooking={() => handleOpenBooking()}
        onOpenAiAdvisor={() => setIsAiAdvisorOpen(true)}
      />

      {/* Core Feature: The WhatsApp Booking System Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        selectedCar={selectedCarForBooking}
        onSelectDifferentCar={handleSelectDifferentCar}
        initialDate={bookingInitialDate}
        initialLocation={bookingInitialLocation}
      />

      {/* Vehicle Specification Drawer / Modal */}
      <CarDetailModal
        car={detailedCar}
        onClose={() => setDetailedCar(null)}
        onBook={(car) => handleOpenBooking(car)}
      />

      {/* AI Moroccan Route & Vehicle Advisor */}
      <AiAdvisorModal
        isOpen={isAiAdvisorOpen}
        onClose={() => setIsAiAdvisorOpen(false)}
        onSelectCar={(car) => handleOpenBooking(car)}
      />
    </div>
  );
}
